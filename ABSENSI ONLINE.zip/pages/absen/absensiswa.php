
<title> Absensi Siswa - <?php echo sekolah; ?> </title>
 <div class="row">
     <div class="col-lg-12">
         <h1 class="page-header">Absensi</h1>
     </div>
     <!-- /.col-lg-12 -->
 </div>
 <!-- /.row -->
 <div class="row">
     <div class="col-lg-12">
         <div class="panel panel-default">
             <div class="panel-heading">
                 Input Data Absen
             </div>
              <div class="panel-body">
                  <div class="row">
                      <div class="col-lg-12">
                        <form method="post" role="form" name="form" onsubmit="return validateForm()">
                          <div class="form-group">
                            <label>Nama Santri</label>
                            <input type="text" name="nama_siswa" id="nama_siswa" class="form-control"/>
                            <p class="help-block">Type min 3 to show siswa!</p>
                          </div>
                          <div class="form-group">
                              <label>Alasan</label>
                              <select name="alasan"class="form-control">
                                  <option>Sakit</option>
                                  <option>Izin</option>
                                  <option>Alpa</option>
                              </select>
                              <p class="help-block">Choose the reason.</p>
                          </div>
                          <div class="form-group">
                            <label>Tanggal</label>
                            <input id="tanggal" name="tanggal" class="form-control datepicker" type="text">
                            <p class="help-block">Choose the date.</p>
                          </div>
                          <button type="submit" name="simpan" class="btn btn-default">Masukan</button>
                          <button type="reset" class="btn btn-default">Reset</button>
                        </form>
                      </div>

                    <!-- /.col-lg-12 -->
                </div>
                <!-- /.row -->
            </div>
          </div>
        </div>
      </div>


 <?php

 if(isset($_POST['simpan']))

 {
    //ganti format tanggal dari datepicker ke mysql
   date_default_timezone_set('Asia/Jakarta');
   $new_date = date("Y-m-d");
   $jam = date("H:i:sa");
 		//ambil 4 karakter pertama
 		$nameonly = substr($_POST['nama_siswa'], 0, 4);

 		//query cek apa udah dimasukin blom absen ini pada tanggal itu
 		$cekudahadaapabelum = mysql_query("SELECT * FROM absen_siswa where (nim_siswa = '$nameonly' AND tanggal LIKE '".$_POST['tanggal']."')");
 			//cek apa udah dimasukin blom absen ini pada tanggal itu
 			if (mysql_num_rows($cekudahadaapabelum) > 0){
 			//if ( $cekudahadaapabelum >= 1 ) {
                 //alert kalo true
 				echo"<script>swal({ title: 'Daarul Uluum Lido',
 								text: 'Udah ada data absennya',
 								timer: 2000,
 								type:'error',
 								showConfirmButton: false });
 					</script>";
                 //insert kalo blom ada
 				} else {

 					$q1=mysql_query("Insert into absen_siswa (`nim_siswa`,`izin`,`tanggal`,`logged`,`id_tahun_ajaran`,`id_semester`,`tanggal_input`,`jam_input`) values
 		               ('".$nameonly."','".$_POST['alasan']."','".$_POST['tanggal']."','".$_SESSION['logged']."','".$_SESSION['id_tahun']."','".$_SESSION['id_semester']."','".$new_date."','".$jam."')");

 							if($q1)
 									{
 										echo"<script>swal({ title: 'Daarul Uluum Lido',
 												text: 'Absensi sudah masuk!',
 												timer: 2000,
 												type:'success',
 												showConfirmButton: false });
 											</script>";

 									}
 									else {
 											echo"<script>swal({ title: 'Daarul Uluum Lido',
 													text: 'Data ada yang error, absensi blom masuk!',
 													timer: 2000,
 													type:'error',
 													showConfirmButton: false });
 												</script>";
 										 }

 						}



 }
 ob_end_flush();
 ?>
 <script type="text/javascript">

     $(function () {
         'use strict';

         var countriesArray = <?php include 'searchsiswa.php'; ?>;

         // Initialize autocomplete with custom appendTo:
         $('#nama_siswa').autocomplete({
             lookup: countriesArray
         })
         $('#tanggal').pickadate(
           {

             disable: [
                  1, 4, 7
                 ],
             format: 'yyyy-mm-dd'

           }
         )
     });


    /* $( function() {
       $.widget( "custom.catcomplete", $.ui.autocomplete, {
         _create: function() {
           this._super();
           this.widget().menu( "option", "items", "> :not(.ui-autocomplete-category)" );
         },
         _renderMenu: function( ul, items ) {
           var that = this,
             currentCategory = "";
           $.each( items, function( index, item ) {
             var li;
             if ( item.KELAS != currentCategory ) {
               ul.append( "<li class='ui-autocomplete-category'>" + item.KELAS + "</li>" );
               currentCategory = item.KELAS;
             }
             li = that._renderItemData( ul, item );
             if ( item.KELAS ) {
               li.attr( "aria-label", item.KELAS + " : " + item.NAMASISWA );
             }
           });
         }
       });
       var data = <?php// include 'searchsiswa.php'; ?>;

       $( "#nama_siswa" ).catcomplete({
         delay: 0,
         source: data
       });
     } );*/


     function validateForm()
     {
       var x=document.forms["form"]["nama_siswa"].value;
       var x1=document.forms["form"]["alasan"].value;
       var x2=document.forms["form"]["tanggal"].value;
         if (x==null || x=="")
           {
             swal({ title: "<?php echo sekolah;?>",
             text: "Namanya jgn kosong",
             timer: 2000,
             type:"error",
             showConfirmButton: false
             });
             return false;
           }
       if (x1==null || x1=="")
         {
           swal({ title: "<?php echo sekolah;?>",
           text: "nama gk kosng 2",
           timer: 2000,
           type:"error",
           showConfirmButton: false
           });
           return false;
         }
       if (x2==null || x2=="")
         {
           swal({ title: "<?php echo sekolah;?>",
           text: "Tanggal jangan lupa diisi",
           timer: 2000,
           type:"error",
           showConfirmButton: false
           });
           return false;
         }
       }
 </script>

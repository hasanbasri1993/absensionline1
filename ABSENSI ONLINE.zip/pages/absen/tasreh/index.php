<?php
include 'db.php';
$idabsen = $_GET['urutanabsen'];


if($idabsen === NULL)
{
$rw=mysql_query("
SELECT
    	absen_siswa.id_data,
    	absen_siswa.nim_siswa,
    	absen_siswa.izin,
    	absen_siswa.tanggal,
    	siswa.nama_siswa,
        guru.nama_guru,
		kls.nama_kelas
FROM
    	absen_siswa
    LEFT JOIN siswa ON absen_siswa.nim_siswa = siswa.nim
    LEFT JOIN guru ON absen_siswa.logged = guru.nid
	Join kelas kls On siswa.namakelas = kls.kode_kelas
ORDER by id_data ASC LIMIT 10
    ");
}
else {
	$rw=mysql_query("
SELECT
    	absen_siswa.id_data,
    	absen_siswa.nim_siswa,
    	absen_siswa.izin,
    	absen_siswa.tanggal,
    	siswa.nama_siswa,
        guru.nama_guru,
		kls.nama_kelas
FROM
    	absen_siswa
    LEFT JOIN siswa ON absen_siswa.nim_siswa = siswa.nim
    LEFT JOIN guru ON absen_siswa.logged = guru.nid
	Join kelas kls On siswa.namakelas = kls.kode_kelas
WHERE
absen_siswa.id_data = '".$idabsen."'
    ");
	}


	while($row = mysql_fetch_array($rw))
{
$originalDate = $row[3];
$newDate = date("l, d-m-Y", strtotime($originalDate));

?>
<br>


        <!-- Custom styles for this template -->
        <link href="style.css" rel="stylesheet">
        <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
        <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
    <!--body onload="myFunction()"-->
     <body>
        <div class="page">
        	<div class="subpage">

                <div class="row">
                    <div class="col-xs-2 col-sm-2 col-md-2 col-lg-2">
                        <h3></h3>
                        <img src="https://absen.daarululuumlido.com/pages/tasreh/yayasan.png" width="71" height="84">
                    </div>
                    <div class="col-lg-8 col-md-8 col-sm-8 col-xs-8">
                        <h3 class="text-center"><span style="color:#3906CA;">YAYASAN SALSABILA LIDO</span></h3>
                        <h3 class="text-center"><span style="color:#3906CA;">SMP DAARUL ULUUM LIDO</span></h3>
                        <p class="MsoNormal" align="center" style="text-align:center;tab-stops:78.0pt 288.75pt"><span lang="EN-US" style="font-size:8.0pt;color:#3906CA">Jl. Mayjen HR. Edi Sukma KM.
22&nbsp; Muara&nbsp;
Ciburuy Cigombong&nbsp;Bogor &nbsp;</span><span lang="EN-US" style="font-size:8.0pt;
font-family:Wingdings;mso-ascii-font-family:&quot;Times New Roman&quot;;mso-hansi-font-family:
&quot;Times New Roman&quot;;color:#3906CA;mso-char-type:symbol;mso-symbol-font-family:
Wingdings">-</span><span lang="EN-US" style="font-size:8.0pt;color:#3906CA"> 16740, </span><span lang="EN-US" style="font-size:8.0pt;font-family:Wingdings;mso-ascii-font-family:
&quot;Times New Roman&quot;;mso-hansi-font-family:&quot;Times New Roman&quot;;color:#3906CA;
mso-char-type:symbol;mso-symbol-font-family:Wingdings">( </span><span lang="EN-US" style="font-size:8.0pt;color:#3906CA"> 0251 – 8224754 / &nbsp;8221305<o:p></o:p></span></p>
                        <img width="450" src="https://absen.daarululuumlido.com/pages/tasreh/list.gif" class="text-center">
                    </div>
                    <div class="col-lg-2 col-md-2 col-sm-2 col-xs-2">
                        <img src="https://absen.daarululuumlido.com/pages/tasreh/du.jpg" width="93" class="text-center img-rounded" height="92">
                        <h3></h3>
                    </div>
                </div>

            <div class="row">
                <div class="col-md-12">
                    <h3><p class="MsoNormal" align="center" style="text-align:center"><b><span lang="AR-SA" dir="RTL" style="font-size:18.0pt">السَّلاَمُ عَلَيْكُمْ وَرَحْمَةُ اللهِ
وَبَرَكَاتُهُ</span></b><b><span lang="EN-US" style="font-size:18.0pt"><o:p></o:p></span></b></p></h3>
                    <p class="MsoNormal"><span class="hps"><b><span lang="EN" style="font-size:18.0pt;mso-ansi-language:EN">With Regards</span></b></span><b><span lang="EN" style="font-size:18.0pt;
mso-ansi-language:EN">,<o:p></o:p></span></b></p>
                </div>
            </div>
            <p><b><span lang="EN" style="font-size:18.0pt;font-family:&quot;Times New Roman&quot;,serif;mso-fareast-font-family:
&quot;Times New Roman&quot;;mso-ansi-language:EN;mso-fareast-language:EN-US;mso-bidi-language:
AR-SA">We</span></b><b><span lang="EN" style="font-size:18.0pt;font-family:&quot;Times New Roman&quot;,serif;mso-fareast-font-family:
&quot;Times New Roman&quot;;mso-ansi-language:EN;mso-fareast-language:EN-US;mso-bidi-language:
AR-SA"> <span class="hps">hereby</span> <span class="hps">inform</span> <span class="hps">Mr. / Mrs. / Miss.</span> <span class="hps">Teacher/</span> <span class="hps">Class Guardian</span> <span class="hps">that the</span> <span class="hps">student</span> <span class="hps">follows</span>:&nbsp;</span></b><br></p>
            <p><b><span lang="EN" style="font-size:18.0pt;font-family:&quot;Times New Roman&quot;,serif;mso-fareast-font-family:
&quot;Times New Roman&quot;;mso-ansi-language:EN;mso-fareast-language:EN-US;mso-bidi-language:
AR-SA">Name&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></b><b><span lang="EN" style="font-size:18.0pt;font-family:&quot;Times New Roman&quot;,serif;
mso-fareast-font-family:&quot;Times New Roman&quot;;mso-ansi-language:EN;mso-fareast-language:
EN-US;mso-bidi-language:AR-SA">:
<?php

    print($row[4]);

?>

</span></b></p>
            <p><b><span lang="EN" style="font-size:18.0pt;font-family:&quot;Times New Roman&quot;,serif;mso-fareast-font-family:
&quot;Times New Roman&quot;;mso-ansi-language:EN;mso-fareast-language:EN-US;mso-bidi-language:
AR-SA">Class&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></b><b><span lang="EN" style="font-size:18.0pt;font-family:&quot;Times New Roman&quot;,serif;
mso-fareast-font-family:&quot;Times New Roman&quot;;mso-ansi-language:EN;mso-fareast-language:
EN-US;mso-bidi-language:AR-SA">:
<?php

    print($row[6]);

?>
<br><!--[endif]--></span></b></p>
            <p><b><span lang="EN" style="font-size:18.0pt;font-family:&quot;Times New Roman&quot;,serif;mso-fareast-font-family:
&quot;Times New Roman&quot;;mso-ansi-language:EN;mso-fareast-language:EN-US;mso-bidi-language:
AR-SA">Room</span></b><b><span lang="EN" style="font-size:18.0pt;font-family:&quot;Times New Roman&quot;,serif;mso-fareast-font-family:
&quot;Times New Roman&quot;;mso-ansi-language:EN;mso-fareast-language:EN-US;mso-bidi-language:
AR-SA"> <span class="hps">/</span> <span class="hps">Dorm &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>:
<?php
    echo " - ";
    //print($row[6]);
?>
</span></b><br></p>
            <p><b><span lang="EN" style="font-size:18.0pt;font-family:&quot;Times New Roman&quot;,serif;mso-fareast-font-family:
&quot;Times New Roman&quot;;mso-ansi-language:EN;mso-fareast-language:EN-US;mso-bidi-language:
AR-SA">can not follow the</span></b><b><span lang="EN" style="font-size:18.0pt;font-family:&quot;Times New Roman&quot;,serif;mso-fareast-font-family:
&quot;Times New Roman&quot;;mso-ansi-language:EN;mso-fareast-language:EN-US;mso-bidi-language:
AR-SA"> <span class="hps">lesson</span> <span class="hps">as it should</span> since
&nbsp;<?=$newDate;?><!-- until __________ 20__ -->, <span class="hps">because of</span>:</span></b><br></p>
            <p><b><span lang="EN" style="font-size:18.0pt;font-family:&quot;Times New Roman&quot;,serif;mso-fareast-font-family:
&quot;Times New Roman&quot;;mso-ansi-language:EN;mso-fareast-language:EN-US;mso-bidi-language:
AR-SA">

(
<?php
if ($row[2] == 'Sakit'){

echo "&nbsp;&#10004;&nbsp";
}
  else
  {
	echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp";
  }
?>
)

Sick&nbsp;</span></b><br></p>
            <p><b><span lang="EN" style="font-size:18.0pt;font-family:&quot;Times New Roman&quot;,serif;mso-fareast-font-family:
&quot;Times New Roman&quot;;mso-ansi-language:EN;mso-fareast-language:EN-US;mso-bidi-language:
AR-SA">
(
<?php
if ($row[2] == 'Izin'){

echo "&nbsp;&#10004;&nbsp";
}
  else
  {
	echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp";
  }
?>)
Permit&nbsp;</span></b><br></p>
            <p><b><span lang="EN" style="font-size:18.0pt;font-family:&quot;Times New Roman&quot;,serif;mso-fareast-font-family:
&quot;Times New Roman&quot;;mso-ansi-language:EN;mso-fareast-language:EN-US;mso-bidi-language:
AR-SA">(&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; ) Other</span></b><br></p>
            <p><b><span lang="EN" style="font-size:18.0pt;font-family:&quot;Times New Roman&quot;,serif;mso-fareast-font-family:
&quot;Times New Roman&quot;;mso-ansi-language:EN;mso-fareast-language:EN-US;mso-bidi-language:
AR-SA">Thank you</span></b><b><span lang="EN" style="font-size:18.0pt;font-family:&quot;Times New Roman&quot;,serif;mso-fareast-font-family:
&quot;Times New Roman&quot;;mso-ansi-language:EN;mso-fareast-language:EN-US;mso-bidi-language:
AR-SA"> <span class="hps">for your attention</span>.</span></b><br></p>
            <p class="MsoNormal" style="margin-left:180.0pt;text-indent:36.0pt"><span class="hps"><b><span lang="EN" style="font-size:18.0pt;mso-ansi-language:EN">Sincerely</span></b></span><b><span lang="EN" style="font-size:18.0pt;
mso-ansi-language:EN">,</span></b></p>
            <p class="MsoNormal" style="margin-left:180.0pt;text-indent:36.0pt"><b><br></b></p>
            <p class="MsoNormal" style="margin-left:180.0pt;text-indent:36.0pt"><b><br></b></p>
            <p class="MsoNormal" style="margin-left:216.0pt"><span class="hps"><b><span lang="EN" style="font-size:18.0pt;
mso-ansi-language:EN">(Head</span></b></span><b><span lang="EN" style="font-size:18.0pt;mso-ansi-language:EN"> Deputy <span class="hps">of</span> <span class="hps">the Student’s Welfare</span>)</span></b><b><span lang="EN-US" style="font-size:18.0pt"><o:p></o:p></span></b></p>
            <p class="MsoNormal" align="center" style="text-align:center"><b><span lang="AR-SA" dir="RTL" style="font-size:18.0pt">وَ السَّلاَمُ عَلَيْكُمْ وَرَحْمَةُ اللهِ
وَبَرَكَاتُهُ</span></b><b><span lang="EN-US" style="font-size:18.0pt"><o:p></o:p></span></b></p>
        </div>
        </div>
        <!-- Bootstrap core JavaScript
    ================================================== -->
        <!-- Placed at the end of the document so the pages load faster -->
        <script src="assets/js/jquery.min.js"></script>
        <script src="bootstrap/js/bootstrap.min.js"></script>
        <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
        <script src="assets/js/ie10-viewport-bug-workaround.js"></script>
        <script type="text/javascript">
        $(function () {
            $("#btnPrint").click(function () {
                var contents = $("#dvContents").html();
                var frame1 = $('<iframe />');
                frame1[0].name = "frame1";
                frame1.css({ "position": "absolute", "top": "-1000000px" });
                $("body").append(frame1);
                var frameDoc = frame1[0].contentWindow ? frame1[0].contentWindow : frame1[0].contentDocument.document ? frame1[0].contentDocument.document : frame1[0].contentDocument;
                frameDoc.document.open();
                //Create a new HTML document.
                frameDoc.document.write('<html><head><title>DIV Contents</title>');
				        //Append the external CSS file.
                frameDoc.document.write('<link href="style.css" rel="stylesheet" type="text/css" />');
				        frameDoc.document.write('<link href="bootstrap/css/bootstrap.css" rel="stylesheet" type="text/css" />');
                frameDoc.document.write('</head><body>');

				//Append the DIV contents.
                frameDoc.document.write(contents);
                frameDoc.document.write('</body></html>');
                frameDoc.document.close();
                setTimeout(function () {
                    window.frames["frame1"].focus();
                    window.frames["frame1"].print();
                    frame1.remove();
                }, 200);
            });

  });
  function myFunction() {
    var contents = $("#dvContents").html();
    var frame1 = $('<iframe />');
    frame1[0].name = "frame1";
    frame1.css({ "position": "absolute", "top": "-1000000px" });
    $("body").append(frame1);
    var frameDoc = frame1[0].contentWindow ? frame1[0].contentWindow : frame1[0].contentDocument.document ? frame1[0].contentDocument.document : frame1[0].contentDocument;
    frameDoc.document.open();
    //Create a new HTML document.
    frameDoc.document.write('<html><head><title>DIV Contents</title>');
//Append the external CSS file.
    frameDoc.document.write('<link href="style.css" rel="stylesheet" type="text/css" />');
frameDoc.document.write('<link href="bootstrap/css/bootstrap.css" rel="stylesheet" type="text/css" />');
    frameDoc.document.write('</head><body>');

//Append the DIV contents.
    frameDoc.document.write(contents);
    frameDoc.document.write('</body></html>');
    frameDoc.document.close();
    setTimeout(function () {
        window.frames["frame1"].focus();
        window.frames["frame1"].print();
        frame1.remove();
    }, 200);
  }
    </script>

<?php
}
?>

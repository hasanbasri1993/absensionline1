<?php

include 'db.php';
$idabsen = $_GET['urutanabsen'];

$rw=mysql_query("

SELECT

    	absen_siswa.id_data,

    	absen_siswa.nim_siswa,

    	absen_siswa.izin,

    	absen_siswa.tanggal,

    	siswa.nama_siswa,

        guru.nama_guru,

		kls.nama_kelas

FROM

    	absen_siswa

    LEFT JOIN siswa ON absen_siswa.nim_siswa = siswa.nim

    LEFT JOIN guru ON absen_siswa.logged = guru.nid

	Join kelas kls On siswa.namakelas = kls.kode_kelas

WHERE

absen_siswa.id_data = '".$idabsen."'

    ");
    if($q1 === FALSE)
           {
             die(mysql_error()); // TODO: better error handling
           }


?>

<br>
        <!-- Custom styles for this template -->

        <link href="http://absen.daarululuumlido.com/pages/tasreh/style.css" rel="stylesheet">

        <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->

        <!--[if lt IE 9]>

      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>

      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>

    <![endif]-->



    <!--body onload="myFunction()"-->

            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Absensi</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Rekap Seluruh Absen Siswa
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">

                        </br>
                        <?
						while($row = mysql_fetch_array($rw))

						{

							$originalDate = $row[3];

							$newDate = date("l, d-m-Y", strtotime($originalDate));

						?>



        <page size="A4" >


jkhj khjk hj khj
          <div class="row">
                  <div class="col-xs-1 col-sm-1 col-md-1 col-lg-1">

                  </div>
                  <div class="col-xs-8 col-sm-8 col-md-8 col-lg-8">

                  </div>
                  <div class="col-xs-1 col-sm-1 col-md-1 col-lg-1">
hjk ghj kghj k
                  </div>
          </div>
          <table>
              <tr>
                <td>
                  <img src="http://absen.daarululuumlido.com/pages/tasreh/yayasan.png" width="71" height="84">
                </td>
                <td>
                  <h3 class="text-center"><span style="color:#3906CA;">YAYASAN SALSABILA LIDO</span></h3>

                  <h3 class="text-center"><span style="color:#3906CA;">SMP DAARUL ULUUM LIDO</span></h3>
                  <p class="MsoNormal" align="center" style="text-align:center;">
                    <span lang="EN-US" style="font-size:8.0pt;color:#3906CA">
                      Jl. Mayjen HR. Edi Sukma KM. 22&nbsp; Muara&nbsp;Ciburuy Cigombong Bogor 16740, 0251 – 8224754 / 8221305<o:p>
                    </span>
                  </p>
                  <img width="500" src="http://absen.daarululuumlido.com/pages/tasreh/list.gif" class="text-center">
                </td>
                <td>
                  <img src="http://absen.daarululuumlido.com/pages/tasreh/du.jpg" width="90" height="auto">
                </td>
              </tr>
          </table>
          </br>
            <div class="row">
                <div class="col-md-12">
                    <h3><p class="arab" align="center">السَّلاَمُ عَلَيْكُمْ وَرَحْمَةُ اللهِ وَبَرَكَاتُهُ</p></h3>
                    <p>With Regards</p>
                </div>
            </div>
            </br>
            <p>We here by inform Mr. / Mrs. / Miss.Teacher/ Class Guardian that the student follows : </p>
            <table>
              <tr>
                <td><p>Name</p></td><td><p>:</p></td><td><p><?=$row[4]; ?></p></td>
              </tr>
              <tr>
                <td><p>Class</p></td><td><p>:</p></td><td><p><?=$row[6]; ?></p></td>
              </tr>
              <tr>
                <td><p>Room / Dorm</td><td><p>:</p></td><td><p> - </p></td>
              </tr>
            </table>
            <p>can not follow the lesson as it should since <?=$newDate;?> because of:</p>
            <p>( <?
                  if ($row[2] == 'Sakit'){
                    echo " &#10004; ";
                    }
                      else
                        {
	                         echo "&nbsp;&nbsp;&nbsp;";
                         }?>
                  ) Sick
             </p>
             <p>( <?
                   if ($row[2] == 'Izin'){
                     echo " &#10004; ";
                     }
                       else
                         {
 	                         echo "&nbsp;&nbsp;&nbsp;";
                          }?>
                   ) Permit
              </p>
              <p>(&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;) Other</p>

            <p>Thank you for your attention </p>

            <p style="margin-left:7cm;">Sincerely</p>
            <br>
            <br>
            <br>
            <p style="margin-left:7cm;">(Head Deputy of the Student’s Welfare)</p>
            <br>
            <h3><p class="arab" align="center">وَعَلَيْكُمُ السَّلاَمُ وَرَحْمَةُ اللهِ وَبَرَكَاتُهُ</p></h3>
</page>
fgh dfghfgdhdfg dfg dfghfgdhfg
<?php
}
?>

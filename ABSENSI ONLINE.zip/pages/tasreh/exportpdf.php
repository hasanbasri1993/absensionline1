<?
if(!isset($_SESSION['role']))
{
  echo "<script>window.location='https://absen.daarululuumlido.com/common/login.php'</script>";
}
include "../../common/mpdf/mpdf.php";

$host	 = "localhost";
$user	 = "daarulul_absen";
$pass	 = "hjve6uly";
$dabname = "daarulul_absen";

$conn = mysql_connect( $host, $user, $pass) or die("Could not connect to mysql server." );
mysql_select_db($dabname, $conn) or die("Could not select database.");

$rw=mysql_query("
SELECT
    	absen_siswa.id_data,
    	absen_siswa.nim_siswa,
    	absen_siswa.izin,
    	absen_siswa.tanggal,
    	siswa.nama_siswa,
      guru.nama_guru,
	  	kls.nama_kelas
FROM
    	absen_siswa
LEFT JOIN siswa ON absen_siswa.nim_siswa = siswa.nim
LEFT JOIN guru ON absen_siswa.logged = guru.nid
Join kelas kls On siswa.namakelas = kls.kode_kelas
ORDER by id_data ASC LIMIT 5
    ");
ob_start();
	while($row = mysql_fetch_array($rw))

						{
							$originalDate = $row[3];
							$newDate = date("l, d-m-Y", strtotime($originalDate));

?>
<page size="A4" id="page">

  <table>
      <tr>
        <td>
          <img src="https://absen.daarululuumlido.com/pages/tasreh/yayasan.png" width="71" height="84">
        </td>
        <td align="center">
          <h3 class="text-center"><span style="color:#3906CA;">YAYASAN SALSABILA LIDO</span></h3>

          <h3 class="text-center"><span style="color:#3906CA;">SMP DAARUL ULUUM LIDO</span></h3>
          <p class="MsoNormal" align="center" style="text-align:center;">
            <span lang="EN-US" style="font-size:8.0pt;color:#3906CA">
              Jl. Mayjen HR. Edi Sukma KM. 22&nbsp; Muara&nbsp;Ciburuy Cigombong Bogor 16740, 0251 – 8224754 / 8221305<o:p>
            </span>
          </p>
          <img width="500" src="https://absen.daarululuumlido.com/pages/tasreh/list.gif" class="text-center">
        </td>
        <td>
          <img src="https://absen.daarululuumlido.com/pages/tasreh/du.jpg" width="90" height="auto">
        </td>
      </tr>
  </table>
  </br>
    <div class="row">
        <div class="col-md-12">
            <h3><p dir="rtl" lang="ar" align="center">السَّلاَمُ عَلَيْكُمْ وَرَحْمَةُ اللهِ وَبَرَكَاتُهُ</p></h3>
            <p>With Regards</p>
        </div>
    </div>
    </br>
    <p>We here by inform Mr. / Mrs. / Miss.Teacher/ Class Guardian that the student follows : </p>
    <table>
      <tr>
        <td><p>Name</p></td><td><p>:</p></td><td><p><?=$row[4]; ?></p></td>
      </tr>
      <tr>
        <td><p>Class</p></td><td><p>:</p></td><td><p><?=$row[6]; ?></p></td>
      </tr>
      <tr>
        <td><p>Room / Dorm</td><td><p>:</p></td><td><p> - </p></td>
      </tr>
    </table>
    <p>can not follow the lesson as it should since <?=$newDate;?> because of:</p>
    <p>( <?
          if ($row[2] == 'Sakit'){
            echo " &#10004; ";
            }
              else
                {
                   echo "&nbsp;&nbsp;&nbsp;";
                 }?>
          ) Sick
     </p>
     <p>( <?
           if ($row[2] == 'Izin'){
             echo " &#10004; ";
             }
               else
                 {
                   echo "&nbsp;&nbsp;&nbsp;";
                  }?>
           ) Permit
      </p>
      <p>(&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;) Other</p>

    <p>Thank you for your attention </p>

    <p style="margin-left:6.5cm;">Sincerely</p>
    <br>
    <br>
    <br>
    <p style="margin-left:6.5cm;">(Head Deputy of the Student’s Welfare)</p>
    <br>
    <h3><p align="center">وَعَلَيْكُمُ السَّلاَمُ وَرَحْمَةُ اللهِ وَبَرَكَاتُهُ</p></h3>
</page>

<?
}
$html = ob_get_contents();
ob_end_clean();
$stylesheet = file_get_contents("https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css");
$stylesheet1 = file_get_contents("https://absen.daarululuumlido.com/pages/tasreh/style.css");
//$html = iconv("windows-1256","UTF-8//IGNORE",$html);
$mpdf=new mPDF("ar","A4");
//$mpdf=new mPDF("utf-8", "A4", 0, "", 10, 10, 5, 1, 1, 1, "");
$mpdf->WriteHTML($stylesheet,1);
$mpdf->WriteHTML($stylesheet1,1);
$mpdf->WriteHTML($html);
$mpdf->Output();

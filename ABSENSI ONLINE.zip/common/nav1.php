<script>
$(function() {
    $(document).on('mouseenter.collapse', '[data-toggle=collapse]', function(e) {
        var $this = $(this),
            href, target = $this.attr('data-target') || e.preventDefault() || (href = $this.attr('href')) && href.replace(/.*(?=#[^\s]+$)/, '') //strip for ie7
            ,
            option = $(target).hasClass('in') ? 'hide' : "show"
            $('.panel-collapse').not(target).collapse("hide")
            $(target).collapse(option);
    })
});

</script>
<nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">

    <div class="navbar-header">

          <button type="button" class="navbar-toggle"  data-toggle="collapse" data-target=".navbar-collapse">
            <span class="sr-only">Toggle navigation</span>

            <span class="icon-bar"></span>

            <span class="icon-bar"></span>

            <span class="icon-bar"></span>

        </button>

        <a class="navbar-brand" href="../index.php"><?php echo 'Selamat Datang  '.$_SESSION['nama']; ?></a>

    </div>

    <? include 'navtop.php'; ?>



    <div class="navbar-default sidebar" role="navigation">

        <div class="sidebar-nav collapse navbar-collapse" data-target=".navbar-collapse">
dfgdf
          <?php  getmenu(11, 11); ?>
fgdf
        </div>

        <!-- /.sidebar-collapse -->

    </div>

    <!-- /.navbar-static-side -->

</nav>
<?
if (isset($_REQUEST["seclevel"])) {
    $seclevel = $_REQUEST["seclevel"];
} else {
    $seclevel = 10;
}
function getmenu($parentid, $myseclevel) {
    $tmpmyseclevel = $myseclevel + 1;
    $query = 'Select * from menu where parentid='.$parentid.' and seclevel < '.$tmpmyseclevel.' order by sortid ASC ';
    $result = mysql_query($query) or die('<h3>Query failed: '.mysql_error().'</h3>');
    $rowcount = mysql_num_rows($result);
    if ($rowcount < 1) {
        return;
    } else {
        echo '<ul class="nav" id="side-menu">';
        while ($row = mysql_fetch_array($result)) {
            echo '<li>'.'<a href="'.$row["url"].'" title="'.$row["desc"].'">'.$row["name"]."</a>";
            $tmpparentid = $row["menuid"];
            getmenu($tmpparentid, $myseclevel);
            echo "</li>";
        }
        echo "</ul>";
    }
}
?>

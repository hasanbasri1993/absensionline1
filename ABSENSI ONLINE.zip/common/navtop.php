<!-- /.navbar-header -->



<ul class="nav navbar-top-links navbar-right">

    <li class="dropdown">
     
        <div class="dropdown">
 			 <button class="btn dropdown-toggle" type="button" data-toggle="dropdown">
             <i class="fa fa-user fa-fw"></i>
  			 <span class="caret"></span></button>
        <ul class="dropdown-menu">

            <li><a href="<?php echo baseurl;?>common/userprofile.php"><i class="fa fa-user fa-fw"></i> User Profile</a>

            </li>

            <li><a href="#"><i class="fa fa-gear fa-fw"></i> Settings</a>

            </li>

            <li class="divider"></li>

            <li><a href="<?php echo baseurl;?>common/logout.php"><i class="fa fa-sign-out fa-fw"></i> Logout</a>

            </li>

        </ul>
		</div>



        <!-- /.dropdown-user -->

    </li>

    <!-- /.dropdown -->

</ul>

<!-- /.navbar-top-links -->


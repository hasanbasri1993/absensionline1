<?php
define('sekolah','SMP Daarl Uluum Lido');
define('baseurl','http://10.10.0.52:8080/absen2/');
define('CSS',baseurl.'common/berkas/css/');
define('JS',baseurl.'common/berkas/js/');
define('IMG',baseurl.'common/berkas/images/');
define('home',baseurl.'pages/home.php');
 ?>

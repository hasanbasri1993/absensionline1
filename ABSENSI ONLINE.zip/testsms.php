<?php
$homepage = file_get_contents('http://webapps.imitra.com:29003/sms_applications/smsb/api_mt_send_message.php?username=dulido_api&password=6564d84b67f9c21768d8e13fa8724d0c&msisdn=6282213542319&sms=Telah%20login%20%20%20HASAN');

echo $homepage;
?>
